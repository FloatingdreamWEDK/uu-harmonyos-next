// Minimal H.264/SCTP session adapted from MIT browserRemoteSession.ts. No diagnostic payload log.
import { ControllerError, asRecord } from './nativeBridge';
import { DesktopInput } from './desktopInput';
import { toBase64 } from './nativeSocket';
import { buildDefaultStreamerDecoderCap, buildStreamerControlStreamerDataJson, buildStreamerRtcConfiguration, decodeStreamerControlMessage, encodeStreamerConnectOptions, encodeStreamerEchoRequestMessage, encodeStreamerEchoResponseMessage, encodeStreamerSpeakerActionMessage, getStreamerSignalControlFailure, STREAMER_CHOOSE_RESOLUTION_TYPES, STREAMER_DATA_CHANNEL_LABELS, STREAMER_FPS_VALUES, STREAMER_SIMPLE_ACTION_TYPES, STREAMER_VIDEO_QUALITY_VALUES } from './upstream/streamerProtocol';
import type { RemoteSignalControlRequest, RemoteSignalControlResult, RemoteSignalGatewayEvent, RemoteSignalSoacRequest, RemoteSignalSoacResult } from './upstream/types';

interface EncodedVideoFrameLike {
  readonly data: ArrayBuffer;
  readonly type?: 'key' | 'delta' | string;
  readonly timestamp?: number;
}

interface EncodedVideoStreams {
  readonly readable: ReadableStream<EncodedVideoFrameLike>;
  readonly writable: WritableStream<EncodedVideoFrameLike>;
}

export type EncodedVideoSink = (data: ArrayBuffer, timestampUs: number, keyFrame: boolean) => void;

export interface SessionSignal {
  sendSignalControl(input: RemoteSignalControlRequest): Promise<RemoteSignalControlResult>;
  sendSignalSoac(input: RemoteSignalSoacRequest): Promise<RemoteSignalSoacResult>;
}
export interface SessionPerformanceOptions {
  fps?: number;
  customBitrateKbps?: number;
  superScreen?: boolean;
  width?: number;
  height?: number;
}
export class RemoteSession {
  readonly input: DesktopInput;
  private peer: RTCPeerConnection | null = null;
  private control: RTCDataChannel | null = null;
  private closed = false;
  private appControlId = '';
  private clientId: string | undefined;
  private iceId: string | undefined;
  private heartbeat: ReturnType<typeof setInterval> | undefined;
  private statsTimer: ReturnType<typeof setTimeout> | undefined;
  private audioStatsTimer: ReturnType<typeof setInterval> | undefined;
  private sequence = 1;
  private remoteAudioEnabled = true;
  private speakerOpenSent = false;
  private queuedCandidates: RTCIceCandidateInit[] = [];
  private media: MediaStream | null = null;
  private frameReceived = false;
  private recorded = new Set<string>();
  private encodedVideoSink: EncodedVideoSink | undefined;
  private encodedVideoCleanup: (() => void) | undefined;
  private encodedAudioCleanup: (() => void) | undefined;
  private encodedVideoAvailable = false;
  private codecConfigBase64 = '';
  private record(stage: string): void { if (!this.recorded.has(stage)) { this.recorded.add(stage); console.info(`UU_REA_RTC|${stage}`); } }
  constructor(private readonly signal: SessionSignal, private readonly createPeer: (configuration: RTCConfiguration) => RTCPeerConnection, private readonly onStream: (stream: MediaStream) => void, private readonly onState: (state: string) => void, private readonly platform: 1 | 4 = 4) {
    this.input = new DesktopInput(message => this.sendInput(message), platform,
      message => this.sendInput(message));
  }
  get inputReady(): boolean { return !this.closed && this.frameReceived && this.peer?.connectionState === 'connected' && this.control?.readyState === 'open'; }
  get nativeEncodedVideoReady(): boolean { return this.encodedVideoAvailable; }
  setEncodedVideoSink(sink: EncodedVideoSink): void { this.encodedVideoSink = sink; }
  get videoCodecConfigBase64(): string { return this.codecConfigBase64; }
  markFrameReceived(): boolean { if (this.closed || !this.media) return false; this.frameReceived = true; this.record('FIRST_FRAME'); return true; }
  releaseInputs(): void {
    if (!this.input.releaseAll()) { this.close(); this.onState('无法释放按键，媒体会话已断开，请重新连接'); }
  }
  async start(deviceId: string, performance: SessionPerformanceOptions = {}): Promise<void> {
    this.appControlId = globalThis.crypto?.randomUUID?.() ?? `uu-rea-${Date.now()}`;
    this.onState('请求控制权限');
    const requestedFps = Number.isFinite(performance.fps) ? Math.trunc(performance.fps!) : 60;
    const fps = Math.min(240, Math.max(1, requestedFps));
    const bitrateKbps = Number.isFinite(performance.customBitrateKbps)
      ? Math.min(200000, Math.max(1, Math.trunc(performance.customBitrateKbps!))) : 0;
    const width = Number.isFinite(performance.width) ? Math.min(7680, Math.max(320, Math.trunc(performance.width!))) : 1920;
    const height = Number.isFinite(performance.height) ? Math.min(4320, Math.max(240, Math.trunc(performance.height!))) : 1080;
    const virtualDisplay = performance.superScreen === true;
    const fpsProfile = fps >= 120 ? STREAMER_FPS_VALUES.FPS_144
      : fps >= 90 ? STREAMER_FPS_VALUES.FPS_90
        : fps >= 60 ? STREAMER_FPS_VALUES.FPS_60 : STREAMER_FPS_VALUES.FPS_30;
    const appData = encodeStreamerConnectOptions({
      deviceId, typeValue: -1,
      captureParams: {
        fps: fpsProfile,
        fpsCount: fps,
        videoQuality: bitrateKbps > 0 ? STREAMER_VIDEO_QUALITY_VALUES.VideoQuality_Custom : STREAMER_VIDEO_QUALITY_VALUES.VideoQuality_Bluray,
        maxCustomBitrate: bitrateKbps * 1000,
        cursorCapture: true,
        chooseResolutionType: STREAMER_CHOOSE_RESOLUTION_TYPES.ChooseType_RESOLUTION,
        localResolution: { width, height },
        chooseResolution: { width, height },
      },
      decoderCapList: [buildDefaultStreamerDecoderCap(fps)],
      forceVirtualDisplay: virtualDisplay,
      virtualDisplayModes: virtualDisplay
        ? [{ width, height, fps }, { width: 2560, height: 1600, fps }]
        : undefined,
      virtualDisplayInitResolution: virtualDisplay ? { width, height } : undefined,
      featureFlags: { ff_capture_setting: 2, ff_simple_action: 1 },
    });
    const ack = await this.signal.sendSignalControl({ appControlId: this.appControlId, appDataBase64: toBase64(appData), streamerData: buildStreamerControlStreamerDataJson({ controlId: this.appControlId }) });
    if (this.closed) return;
    const result = ack.control.result;
    if (!result || getStreamerSignalControlFailure(ack.control)) {
      this.record('CONTROL_REJECTED');
      if (typeof result?.code === 'number' && Number.isInteger(result.code) && Math.abs(result.code) <= 99999) console.info(`UU_REA_CONTROL_RESULT|${result.code}`);
      throw new ControllerError('SIGNAL_FAILED');
    }
    this.record('CONTROL_OK');
    if (!result.clientId || !result.iceId) this.record('CONTROL_IDS_MISSING');
    this.clientId = result.clientId;
    this.iceId = result.iceId;
    const peer = this.createPeer(buildStreamerRtcConfiguration(result));
    this.peer = peer;
    this.statsTimer = setTimeout(() => {
      void peer.getStats().then(report => {
        if (this.closed || this.peer !== peer) return;
        const counters = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        const relayChecks = [0, 0, 0, 0, 0, 0];
        report.forEach(item => {
          if (item.type === 'local-candidate') {
            counters[5]!++;
            if (item.candidateType === 'relay' && ['udp', 'tcp', 'tls'].includes(item.relayProtocol)) counters[item.relayProtocol === 'udp' ? 9 : item.relayProtocol === 'tcp' ? 10 : 11]!++;
          }
          if (item.type === 'remote-candidate') counters[6]!++;
          if (item.type !== 'candidate-pair') return;
          const local = report.get(item.localCandidateId);
          const relayIndex = local?.candidateType === 'relay' ? ['udp', 'tcp', 'tls'].indexOf(local.relayProtocol) : -1;
          if (relayIndex >= 0) for (const [offset, field] of [[0, 'requestsSent'], [1, 'responsesReceived']] as const) {
            const value: unknown = item[field];
            if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) relayChecks[relayIndex * 2 + offset]! += value;
          }
          counters[0]!++;
          for (const [index, field] of [[1, 'requestsSent'], [2, 'responsesReceived'], [3, 'bytesReceived'], [4, 'bytesSent'], [7, 'requestsReceived'], [8, 'responsesSent']] as const) {
            const value: unknown = item[field];
            if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) counters[index]! += value;
          }
        });
        if (counters.every(value => Number.isSafeInteger(value) && value >= 0)) console.info(`UU_REA_ICE_STATS|${counters.join('|')}`);
        if (relayChecks.every(value => Number.isSafeInteger(value) && value >= 0)) console.info(`UU_REA_ICE_RELAY_CHECKS|${relayChecks.join('|')}`);
        const kind = (value: unknown): string => typeof value === 'string' && ['host', 'srflx', 'prflx', 'relay'].includes(value) ? value.toUpperCase() : 'OTHER';
        const protocol = (value: unknown): string => typeof value === 'string' && ['udp', 'tcp', 'tls'].includes(value) ? value.toUpperCase() : 'OTHER';
        report.forEach(item => {
          if (item.type !== 'transport' || typeof item.selectedCandidatePairId !== 'string') return;
          const pair = report.get(item.selectedCandidatePairId);
          const local = pair && report.get(pair.localCandidateId), remote = pair && report.get(pair.remoteCandidateId);
          if (local?.type === 'local-candidate' && remote?.type === 'remote-candidate') console.info(`UU_REA_ICE_SELECTED|${kind(local.candidateType)}|${protocol(local.relayProtocol)}|${kind(remote.candidateType)}|${remote.protocol === 'udp' ? 'UDP' : remote.protocol === 'tcp' ? 'TCP' : 'OTHER'}`);
        });
      }).catch(() => {});
    }, 15000);
    console.info(`UU_REA_ICE_CONFIG|${result.iceServers.length}|${peer.getConfiguration?.().iceTransportPolicy === 'relay' ? 'RELAY' : 'ALL'}`);
    for (const server of result.iceServers) for (const url of Array.isArray(server.urls) ? server.urls : [server.urls]) {
      const origin = /^(stun|turn|turns):(?:\/\/)?(\[[0-9a-f:]+\]|[a-z0-9.-]+)(?::([0-9]{1,5}))?(?:\?transport=(?:udp|tcp))?$/i.exec(url);
      if (origin) console.info(`UU_REA_ICE_ORIGIN|${origin[1]!.toUpperCase()}|${origin[2]!.toLowerCase()}|${origin[3] ?? (origin[1]!.toLowerCase() === 'turns' ? 5349 : 3478)}`);
    }
    peer.oniceconnectionstatechange = () => {
      if (!this.closed && ['new', 'checking', 'connected', 'completed', 'disconnected', 'failed', 'closed'].includes(peer.iceConnectionState)) console.info(`UU_REA_ICE_STATE|${peer.iceConnectionState.toUpperCase()}`);
    };
    peer.onicecandidateerror = event => {
      if (!this.closed && Number.isInteger(event.errorCode) && event.errorCode >= 0 && event.errorCode <= 999) {
        console.info(`UU_REA_ICE_ERROR|${event.errorCode}`);
        const endpoint = event.url?.startsWith('turns:relay.nrd.nie.163.com:443') ? 'DOMAIN_TLS' : event.url?.startsWith('turns:') ? 'IP_TLS' : event.url?.startsWith('turn:') ? (event.url.endsWith('?transport=tcp') ? 'TCP_RELAY' : 'UDP_RELAY') : 'STUN';
        const reason = /tls|ssl|certificate/i.test(event.errorText) ? 'TLS' : /lookup|resolv|name resolution/i.test(event.errorText) ? 'DNS' : /timed? ?out|timeout/i.test(event.errorText) ? 'TIMEOUT' : 'OTHER';
        console.info(`UU_REA_ICE_FAILURE|${endpoint}|${reason}`);
      }
    };
    for (const label of Object.values(STREAMER_DATA_CHANNEL_LABELS)) {
      const channel = peer.createDataChannel(label);
      channel.binaryType = 'arraybuffer';
      if (label !== STREAMER_DATA_CHANNEL_LABELS.control) continue;
      this.control = channel;
      channel.onopen = () => {
        if (this.closed) return;
        this.sendSpeakerAction(this.remoteAudioEnabled);
        this.onState('控制通道已打开，等待画面');
        this.sendHeartbeat();
        this.heartbeat = setInterval(() => this.sendHeartbeat(), 100);
      };
      channel.onclose = () => { this.stopHeartbeat(); if (!this.closed) this.onState('控制通道已关闭'); };
      channel.onerror = () => { this.stopHeartbeat(); if (!this.closed) this.onState('控制通道错误'); };
      channel.onmessage = event => {
        if (!(event.data instanceof ArrayBuffer) || this.closed) return;
        this.record('CONTROL_DATA_RECEIVED');
        try {
          const message = decodeStreamerControlMessage(event.data);
          if (message.simpleAction?.action !== STREAMER_SIMPLE_ACTION_TYPES.ACTION_TYPE_ECHO_REQUEST) return;
          const responseSequence = message.simpleAction.seq ?? message.sequence;
          if (responseSequence !== undefined && !this.closed && channel.readyState === 'open') channel.send(encodeStreamerEchoResponseMessage({ sequence: this.sequence++, timestampMs: this.timestamp(), responseSequence, featureFlags: {} }));
        } catch { /* Unknown control notifications are ignored; their contents are never logged. */ }
      };
    }
    const codecs = globalThis.RTCRtpReceiver?.getCapabilities?.('video')?.codecs ?? [];
    const h264 = codecs.filter(codec => codec.mimeType.toLowerCase() === 'video/h264');
    const rtx = codecs.filter(codec => codec.mimeType.toLowerCase() === 'video/rtx');
    if (h264.length === 0) throw new ControllerError('WEBRTC_UNSUPPORTED');
    // UU reserves five desktop video slots; this UI renders the first screen only.
    for (let index = 0; index < 5; index++) {
      const transceiver = peer.addTransceiver('video', { direction: 'recvonly' });
      transceiver.setCodecPreferences([...h264, ...rtx]);
      if (index === 0 && transceiver.receiver) this.attachEncodedVideo(transceiver.receiver);
    }
    const audioTransceiver = peer.addTransceiver('audio', { direction: 'recvonly' });
    this.attachEncodedAudioDump(audioTransceiver.receiver);
    // Experiment: UU may bind system sound to a second audio track index.
    peer.addTransceiver('audio', { direction: 'recvonly' });
    peer.onicecandidate = event => {
      if (!event.candidate || this.closed) return;
      this.record('LOCAL_CANDIDATE');
      const candidate = event.candidate.toJSON();
      this.recordCandidate('LOCAL', candidate.candidate ?? '');
      void this.sendSoac({ type: 'candidate', candidate: { candidate: candidate.candidate ?? '', sdpMid: candidate.sdpMid ?? undefined, sdpMLineIndex: candidate.sdpMLineIndex ?? undefined } }).catch(() => { if (!this.closed) this.onState('ICE 候选发送失败'); });
    };
    peer.ontrack = event => {
      if (this.closed || !['video', 'audio'].includes(event.track.kind)) return;
      if (!this.media) this.media = new MediaStream();
      if (!this.media.getTracks().some(track => track.id === event.track.id)) {
        this.media.addTrack(event.track);
      }
      if (event.track.kind === 'video') {
        this.record('VIDEO_TRACK');
      } else {
        this.record('AUDIO_TRACK');
        console.info(`UU_REA_AUDIO_TRACK|${event.track.muted ? 1 : 0}|${event.track.enabled ? 1 : 0}|${event.track.readyState === 'live' ? 1 : 0}`);
        this.startAudioStats();
      }
      this.onStream(this.media);
      if (event.track.kind === 'video') this.onState('已收到视频轨道，等待首帧');
      else this.onState('已收到远程音频');
    };
    peer.onconnectionstatechange = () => {
      if (this.closed) return;
      if (['disconnected', 'failed', 'closed'].includes(peer.connectionState)) { this.record('ICE_FAILED'); this.close(); this.onState('媒体连接已中断，请断开后重连'); }
      else if (peer.connectionState === 'connected') { this.record('ICE_CONNECTED'); this.onState(this.frameReceived ? '媒体连接已建立，可启用输入' : '媒体连接已建立，等待首帧'); }
    };
    const offer = await peer.createOffer();
    if (this.closed) return;
    await peer.setLocalDescription(offer);
    if (this.closed) return;
    // Windows uses the fixed MIT reference's appAuto mode (3); retain the accepted Mac route.
    await this.sendSoac({ type: 'offer', sdp: offer.sdp, gzipSdp: false, iceNetworkType: this.platform === 1 ? 3 : 2 });
    this.record('OFFER_SENT');
    if (!this.closed) this.onState('已发送 H.264 SDP，等待被控端');
  }
  async apply(event: RemoteSignalGatewayEvent): Promise<void> {
    if (this.closed || event.event !== 'soac') return;
    for (const payload of Array.isArray(event.payload) ? event.payload : [event.payload]) {
      const record = asRecord(payload), data = asRecord(record.data);
      this.record(data.type === 'answer' || data.type === 'restart_ice' ? 'SOAC_ANSWER' : data.type === 'candidate' ? 'SOAC_CANDIDATE' : 'SOAC_OTHER');
      if (!this.peer) { this.record('NO_PEER'); continue; }
      if ((record.client_id && record.client_id !== this.clientId) || (data.app_control_id && data.app_control_id !== this.appControlId) || (data.ice_id && this.iceId && data.ice_id !== this.iceId)) { this.record('SCOPE_MISMATCH'); continue; }
      if ((data.type === 'answer' || data.type === 'restart_ice') && (typeof data.sdp !== 'string' || !data.sdp)) this.record('ANSWER_EMPTY');
      if ((data.type === 'answer' || data.type === 'restart_ice') && typeof data.sdp === 'string' && this.peer.signalingState === 'have-local-offer') {
        await this.peer.setRemoteDescription({ type: 'answer', sdp: data.sdp });
        this.captureVideoCodecConfig(data.sdp);
        this.logAudioSdp(data.sdp);
        this.record('ANSWER_APPLIED');
        if (this.closed) return;
        for (const candidate of this.queuedCandidates.splice(0)) await this.peer.addIceCandidate(candidate);
        this.onState('SDP 已协商，等待媒体');
      } else if (data.type === 'candidate') {
        const candidate = asRecord(data.candidate);
        if (typeof candidate.candidate !== 'string') continue;
        this.recordCandidate('REMOTE', candidate.candidate);
        const init: RTCIceCandidateInit = { candidate: candidate.candidate, sdpMid: typeof candidate.sdpMid === 'string' ? candidate.sdpMid : null, sdpMLineIndex: typeof candidate.sdpMLineIndex === 'number' ? candidate.sdpMLineIndex : null };
        if (this.peer.remoteDescription) await this.peer.addIceCandidate(init); else this.queuedCandidates.push(init);
      }
    }
  }
  close(): void {
    clearTimeout(this.statsTimer); this.statsTimer = undefined;
    clearInterval(this.audioStatsTimer); this.audioStatsTimer = undefined;
    this.input.releaseAll();
    this.closed = true;
    this.frameReceived = false;
    this.stopHeartbeat();
    this.control = null;
    this.encodedVideoCleanup?.();
    this.encodedVideoCleanup = undefined;
    this.encodedAudioCleanup?.();
    this.encodedAudioCleanup = undefined;
    this.peer?.close();
    this.peer = null;
    this.media?.getTracks().forEach(track => track.stop());
    this.media = null;
    this.queuedCandidates = [];
    this.appControlId = ''; this.clientId = undefined; this.iceId = undefined;
    this.speakerOpenSent = false;
  }
  private attachEncodedVideo(receiver: RTCRtpReceiver | undefined): void {
    if (!receiver) return;
    const source = receiver as unknown as { createEncodedStreams?: () => EncodedVideoStreams };
    if (typeof source.createEncodedStreams !== 'function') {
      this.record('ENCODED_STREAMS_UNAVAILABLE');
      return;
    }
    try {
      const streams = source.createEncodedStreams();
      const reader = streams.readable.getReader();
      const writer = streams.writable.getWriter();
      let cancelled = false;
      this.encodedVideoCleanup = () => {
        cancelled = true;
        void reader.cancel().catch(() => {});
        void writer.close().catch(() => {});
      };
      void (async () => {
        try {
          while (!cancelled && !this.closed) {
            const item = await reader.read();
            if (item.done) break;
            const frame = item.value;
            const data = frame.data.slice(0);
            const timestamp = typeof frame.timestamp === 'number' && Number.isFinite(frame.timestamp) && frame.timestamp >= 0
              ? frame.timestamp : Math.floor(performance.now() * 1000);
            this.encodedVideoSink?.(data, timestamp, frame.type === 'key');
            if (cancelled) break;
            await writer.write(frame);
          }
        } catch {
          this.record('ENCODED_STREAMS_FAILED');
        } finally {
          try { reader.releaseLock(); } catch { /* Already cancelled. */ }
          try { writer.releaseLock(); } catch { /* Already closed. */ }
        }
      })();
      this.record('ENCODED_STREAMS_READY');
      this.encodedVideoAvailable = true;
    } catch {
      this.encodedVideoAvailable = false;
      this.record('ENCODED_STREAMS_UNAVAILABLE');
    }
  }
  private logAudioSdp(sdp: string): void {
    const sections = sdp.split(/\r?\nm=/);
    let index = 0;
    for (const section of sections) {
      if (!section.startsWith('audio')) continue;
      const rtpmap = /a=rtpmap:\d+ ([A-Za-z0-9_+-]+)/.exec(section);
      const dir = /a=(sendrecv|sendonly|recvonly|inactive)/.exec(section);
      const ssrcs = (section.match(/^a=ssrc:/gm) ?? []).length;
      const groups = (section.match(/^a=ssrc-group:/gm) ?? []).length;
      console.info(`UU_REA_SDP_AUDIO|${index}|${rtpmap?.[1] ?? '-'}|${dir?.[1] ?? '-'}|${ssrcs}|${groups}`);
      index++;
    }
    if (index === 0) console.info('UU_REA_SDP_AUDIO|0|-|-|0|0');
  }
  private attachEncodedAudioDump(receiver: RTCRtpReceiver | undefined): void {
    if (!receiver) return;
    const source = receiver as unknown as { createEncodedStreams?: () => EncodedVideoStreams };
    if (typeof source.createEncodedStreams !== 'function') {
      console.info('UU_REA_AUDIO_PKT|UNAVAILABLE');
      return;
    }
    try {
      const streams = source.createEncodedStreams();
      const reader = streams.readable.getReader();
      const writer = streams.writable.getWriter();
      let dumped = 0;
      let cancelled = false;
      this.encodedAudioCleanup = () => {
        cancelled = true;
        void reader.cancel().catch(() => {});
        void writer.close().catch(() => {});
      };
      void (async () => {
        try {
          while (!cancelled && !this.closed) {
            const item = await reader.read();
            if (item.done) break;
            const frame = item.value;
            if (dumped < 8) {
              const bytes = new Uint8Array(frame.data as ArrayBuffer).slice(0, 180);
              console.info(`UU_REA_AUDIO_PKT|${dumped}|${bytes.byteLength}|${toBase64(bytes)}`);
              dumped++;
            }
            await writer.write(frame);
          }
        } catch {
          console.info('UU_REA_AUDIO_PKT|FAILED');
        } finally {
          try { reader.releaseLock(); } catch { /* already released */ }
          try { writer.releaseLock(); } catch { /* already released */ }
        }
      })();
    } catch {
      console.info('UU_REA_AUDIO_PKT|UNAVAILABLE');
    }
  }
  private captureVideoCodecConfig(sdp: string): void {
    const match = /(?:^|\r?\n)a=fmtp:[^\r\n]*sprop-parameter-sets=([^;\r\n]+)/i.exec(sdp);
    if (!match?.[1]) return;
    try {
      const parts: number[] = [];
      for (const item of match[1].split(',')) {
        const binary = atob(item.trim());
        parts.push(0, 0, 0, 1);
        for (let index = 0; index < binary.length; index++) parts.push(binary.charCodeAt(index));
      }
      if (parts.length > 0) this.codecConfigBase64 = toBase64(Uint8Array.from(parts));
    } catch {
      this.record('CODEC_CONFIG_INVALID');
    }
  }
  private sendInput(message: string | Uint8Array): void {
    if (!this.inputReady || !this.control) throw new ControllerError('INPUT_NOT_READY');
    if (message instanceof Uint8Array) {
      this.control.send(message);
    } else {
      this.control.send(message);
    }
    this.record('INPUT_SENT');
    if (message instanceof Uint8Array) {
      this.record('INPUT_NATIVE_TOUCH_SENT');
      return;
    }
    let action: unknown;
    try { action = asRecord(JSON.parse(message)).action; }
    catch {
      if (message.includes('SLOTMULTIPRESS') || message.includes('SLOTMULTIRELEASE')) {
        this.record('INPUT_TOUCH_SENT');
      }
      return;
    }
    if (action === 'mouse_move_absolute') this.record('INPUT_MOVE_SENT');
    else if (action === 'mouse_move_relative') this.record('INPUT_TOUCHPAD_MOVE_SENT');
    else if (action === 'mouse_press' || action === 'mouse_release') this.record('INPUT_BUTTON_SENT');
    else if (action === 'kbd_press' || action === 'kbd_release') { this.record('INPUT_KEY_SENT'); this.record(action === 'kbd_press' ? 'INPUT_KEY_PRESS_SENT' : 'INPUT_KEY_RELEASE_SENT'); }
  }
  private timestamp(): number { return Math.floor(Date.now() / 1000); }
  private startAudioStats(): void {
    if (this.audioStatsTimer || !this.peer) return;
    const sample = (): void => {
      const peer = this.peer;
      if (this.closed || !peer) return;
      void peer.getStats().then(report => {
        if (this.closed || this.peer !== peer) return;
        let index = 0;
        report.forEach(item => {
          const record = item as unknown as Record<string, unknown>;
          const kind = record.kind ?? record.mediaType;
          if (item.type !== 'inbound-rtp' || kind !== 'audio') return;
          const number = (name: string): number => {
            const value = record[name];
            return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : 0;
          };
          console.info(`UU_REA_AUDIO_RTP|${index}|${Math.floor(number('bytesReceived'))}|${Math.floor(number('packetsReceived'))}|${Math.floor(number('totalSamplesDuration'))}`);
          index++;
        });
        if (index === 0) console.info('UU_REA_AUDIO_RTP|none');
      }).catch(() => console.info('UU_REA_AUDIO_STATS|FAILED'));
    };
    this.audioStatsTimer = setInterval(sample, 5000);
    sample();
  }
  private recordCandidate(direction: 'LOCAL' | 'REMOTE', value: string): void {
    const protocol = /^candidate:\S+\s+[0-9]+\s+(udp|tcp)\s/i.exec(value)?.[1]?.toUpperCase() ?? 'OTHER';
    const kind = /\styp\s+(host|srflx|prflx|relay)(?:\s|$)/i.exec(value)?.[1]?.toUpperCase() ?? 'OTHER';
    console.info(`UU_REA_ICE_CANDIDATE|${direction}|${kind}|${protocol}`);
  }
  setRemoteAudio(enabled: boolean): void {
    this.remoteAudioEnabled = enabled;
    this.sendSpeakerAction(enabled);
  }
  private sendSpeakerAction(open: boolean): void {
    if (this.closed || !this.control || this.control.readyState !== 'open' || open === this.speakerOpenSent) return;
    this.control.send(encodeStreamerSpeakerActionMessage({ sequence: this.sequence++, timestampMs: this.timestamp(), open, featureFlags: {} }));
    this.speakerOpenSent = open;
    console.info(open ? 'UU_REA_RTC|SPEAKER_OPEN_SENT' : 'UU_REA_RTC|SPEAKER_CLOSE_SENT');
  }

  private sendHeartbeat(): void {
    if (this.closed || this.control?.readyState !== 'open') return;
    if (this.speakerOpenSent !== this.remoteAudioEnabled) this.sendSpeakerAction(this.remoteAudioEnabled);
    try {
      this.control.send(encodeStreamerEchoRequestMessage({ sequence: this.sequence++, timestampMs: this.timestamp(), featureFlags: {} }));
      // Official Mac 4.39.1 InputManager independently updates InputHandler's
      // input heartbeat from this JSON boolean, separate from protocol Echo.
      this.control.send('{"heartbeat":true}');
    }
    catch { if (this.control.readyState !== 'open') this.stopHeartbeat(); }
  }
  private stopHeartbeat(): void { if (this.heartbeat) clearInterval(this.heartbeat); this.heartbeat = undefined; }
  private sendSoac(input: RemoteSignalSoacRequest): Promise<RemoteSignalSoacResult> {
    return this.signal.sendSignalSoac({ ...input, appControlId: this.appControlId, clientId: this.clientId, iceId: this.iceId });
  }
}
