import { expect, it } from 'vitest';
import { DesktopInput } from '../src/desktopInput';

it('uses Windows VK keys and releases stale and held modifiers for a Windows target', () => {
  const messages: string[] = [];
  const input = new DesktopInput(message => messages.push(message), 1);
  input.move(100, 75, 200, 100);
  input.key({ code: 'ControlLeft', key: 'Control', ctrlKey: true }, true);
  input.key({ code: 'KeyA', key: 'a', ctrlKey: false }, true);
  input.key({ code: 'KeyA', key: 'a', ctrlKey: false }, true);
  input.key({ code: 'Backspace', key: 'Backspace' }, true);
  input.releaseAll();
  expect(messages.map(message => JSON.parse(message))).toEqual([
    { action: 'mouse_move_absolute', abs_x: 0.5, abs_y: 0.75 },
    { action: 'kbd_press', key: 162, interrept: true },
    { action: 'kbd_release', key: 162, interrept: true },
    { action: 'kbd_press', key: 65, interrept: true },
    { action: 'kbd_press', key: 8, interrept: true },
    { action: 'kbd_release', key: 65, interrept: true },
    { action: 'kbd_release', key: 8, interrept: true },
  ]);
});

it('releases a stale Command before ordinary typing or pointer input while preserving real shortcuts', () => {
  const messages: string[] = [];
  const input = new DesktopInput(message => messages.push(message));
  input.key({ code: 'MetaLeft', key: 'Meta', metaKey: true }, true);
  input.key({ code: 'Digit8', key: '8', metaKey: false }, true);
  input.key({ code: 'Digit8', key: '8', metaKey: false }, false);
  input.key({ code: 'MetaLeft', key: 'Meta', metaKey: false }, true);
  input.key({ code: 'MetaLeft', key: 'Meta', metaKey: true }, true);
  input.key({ code: 'Digit8', key: '8', metaKey: true }, true);
  input.key({ code: 'Digit8', key: '8', metaKey: true }, false);
  input.syncModifiers({ metaKey: false });
  expect(messages.map(message => JSON.parse(message))).toEqual([
    { action: 'kbd_press', key: 55 }, { action: 'kbd_release', key: 55 },
    { action: 'kbd_press', key: 28 }, { action: 'kbd_release', key: 28 },
    { action: 'kbd_press', key: 55 }, { action: 'kbd_press', key: 28 },
    { action: 'kbd_release', key: 28 }, { action: 'kbd_release', key: 55 },
  ]);
});

it('accepts a first received repeat event, suppresses held duplicates and accepts the key again after release', () => {
  const messages: string[] = [];
  const input = new DesktopInput(message => messages.push(message));
  const event = { code: 'Digit8', key: '8', repeat: true };
  input.key(event, true);
  input.key(event, true);
  input.key(event, false);
  input.key(event, true);
  input.releaseAll();
  expect(messages.map(message => JSON.parse(message))).toEqual([
    { action: 'kbd_press', key: 28 }, { action: 'kbd_release', key: 28 },
    { action: 'kbd_press', key: 28 }, { action: 'kbd_release', key: 28 },
  ]);
});

it('uses normalized desktop pointer coordinates and Mac key codes, releasing held inputs before close', () => {
  const messages: string[] = [];
  const input = new DesktopInput(message => messages.push(message));
  input.move(100, 75, 200, 100);
  input.button(2, true);
  input.key({ code: 'KeyA', key: 'a' }, true);
  input.releaseAll();
  expect(messages.map(message => JSON.parse(message))).toEqual([
    { action: 'mouse_move_absolute', abs_x: 0.5, abs_y: 0.75 },
    { action: 'mouse_press', button: 2 },
    { action: 'kbd_press', key: 0 },
    { action: 'mouse_release', button: 2 },
    { action: 'kbd_release', key: 0 },
  ]);
  input.releaseAll();
  expect(messages).toHaveLength(5);
});

it('forwards multiple touch points through the official Windows SLOTMULTI protocol and releases all slots', () => {
  const messages: string[] = [];
  const input = new DesktopInput(message => messages.push(message), 1);
  input.touch([{ id: 7, relX: 0.25, relY: 0.5 }, { id: 9, relX: 0.75, relY: 0.2 }], 1000, 800);
  input.endTouch();
  expect(messages).toEqual([
    '0:SLOTMULTIPRESS:26:26:250:400:27:27:750:160\n',
    '0:SLOTMULTIRELEASE:26:27:28:29:30:31\n',
  ]);
});

it('sends relative pointer movement for touchpad mode', () => {
  const messages: string[] = [];
  const input = new DesktopInput(message => messages.push(message), 1);
  input.moveRelative(12.4, -8.2);
  expect(messages.map(message => JSON.parse(message))).toEqual([
    { action: 'mouse_move_relative', delta_x: 12, delta_y: -8 },
  ]);
});
