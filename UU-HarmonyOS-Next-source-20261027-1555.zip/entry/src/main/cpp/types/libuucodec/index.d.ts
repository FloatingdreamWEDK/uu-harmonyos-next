export interface CodecProbeResult {
  supported: boolean;
  hardware: boolean;
  name: string;
  mime: string;
  maxInstances: number;
  error: string;
}

export interface HardwareDecoderResult {
  started: boolean;
  hardware: boolean;
  name: string;
  error: string;
}

export interface DecoderStats {
  queued: number;
  submitted: number;
  decoded: number;
  lastError: number;
}

export function probeHardwareDecoder(mime: string): CodecProbeResult;

export function startHardwareDecoder(
  surfaceId: string,
  mime: string,
  width: number,
  height: number,
  fps: number,
  codecConfig: ArrayBuffer | undefined
): HardwareDecoderResult;

export function pushDecodeFrame(
  data: ArrayBuffer,
  timestampUs: number,
  keyFrame: boolean
): boolean;

export function decoderStats(): DecoderStats;

export function stopHardwareDecoder(): void;
