#include "napi/native_api.h"

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

#include "multimedia/player_framework/native_avbuffer.h"
#include "multimedia/player_framework/native_avcapability.h"
#include "multimedia/player_framework/native_avcodec_videodecoder.h"
#include "multimedia/player_framework/native_avformat.h"
#include "native_window/external_window.h"

namespace {

constexpr size_t MAX_QUEUED_FRAMES = 120;
constexpr size_t MAX_FRAME_BYTES = 8 * 1024 * 1024;

struct EncodedFrame {
  std::vector<uint8_t> bytes;
  int64_t ptsUs = 0;
  uint32_t flags = AVCODEC_BUFFER_FLAGS_NONE;
};

struct DecoderContext {
  std::mutex mutex;
  std::deque<EncodedFrame> queue;
  OH_AVCodec *codec = nullptr;
  OHNativeWindow *window = nullptr;
  OH_AVBuffer *waitingInputBuffer = nullptr;
  uint32_t waitingInputIndex = UINT32_MAX;
  uint64_t submittedFrames = 0;
  uint64_t decodedFrames = 0;
  int32_t lastError = 0;
  bool started = false;
  std::string codecName;
};

DecoderContext gDecoder;

const char *MimeForCodec(const std::string &codec) {
  if (codec == "h264" || codec == "video/avc") {
    return OH_AVCODEC_MIMETYPE_VIDEO_AVC;
  }
  if (codec == "h265" || codec == "hevc" || codec == "video/hevc") {
    return OH_AVCODEC_MIMETYPE_VIDEO_HEVC;
  }
  return nullptr;
}

napi_value MakeBoolean(napi_env env, bool value) {
  napi_value result = nullptr;
  napi_get_boolean(env, value, &result);
  return result;
}

napi_value MakeString(napi_env env, const std::string &value) {
  napi_value result = nullptr;
  napi_create_string_utf8(env, value.c_str(), value.size(), &result);
  return result;
}

napi_value MakeUint32(napi_env env, uint32_t value) {
  napi_value result = nullptr;
  napi_create_uint32(env, value, &result);
  return result;
}

void SetNamed(napi_env env, napi_value object, const char *name, napi_value value) {
  napi_set_named_property(env, object, name, value);
}

napi_value Probe(napi_env env, napi_callback_info info) {
  size_t argc = 1;
  napi_value args[1] = {nullptr};
  napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);

  size_t length = 0;
  if (argc < 1 || napi_get_value_string_utf8(env, args[0], nullptr, 0, &length) != napi_ok) {
    napi_value result = nullptr;
    napi_create_object(env, &result);
    SetNamed(env, result, "supported", MakeBoolean(env, false));
    SetNamed(env, result, "hardware", MakeBoolean(env, false));
    SetNamed(env, result, "name", MakeString(env, ""));
    SetNamed(env, result, "mime", MakeString(env, ""));
    SetNamed(env, result, "maxInstances", MakeUint32(env, 0));
    SetNamed(env, result, "error", MakeString(env, "invalid_mime"));
    return result;
  }

  std::string codec(length, '\0');
  napi_get_value_string_utf8(env, args[0], codec.data(), length + 1, &length);
  codec.resize(length);
  const char *mime = MimeForCodec(codec);

  napi_value result = nullptr;
  napi_create_object(env, &result);
  SetNamed(env, result, "mime", MakeString(env, mime == nullptr ? codec : mime));

  OH_AVCapability *capability =
      mime == nullptr ? nullptr : OH_AVCodec_GetCapabilityByCategory(mime, false, HARDWARE);
  if (capability == nullptr) {
    SetNamed(env, result, "supported", MakeBoolean(env, false));
    SetNamed(env, result, "hardware", MakeBoolean(env, false));
    SetNamed(env, result, "name", MakeString(env, ""));
    SetNamed(env, result, "maxInstances", MakeUint32(env, 0));
    SetNamed(env, result, "error", MakeString(env, "hardware_decoder_unavailable"));
    return result;
  }

  const char *name = OH_AVCapability_GetName(capability);
  SetNamed(env, result, "supported", MakeBoolean(env, true));
  SetNamed(env, result, "hardware", MakeBoolean(env, OH_AVCapability_IsHardware(capability)));
  SetNamed(env, result, "name", MakeString(env, name == nullptr ? "" : name));
  SetNamed(env, result, "maxInstances",
           MakeUint32(env, static_cast<uint32_t>(std::max(0, OH_AVCapability_GetMaxSupportedInstances(capability)))));
  SetNamed(env, result, "error", MakeString(env, ""));
  return result;
}

void OnNeedInputBuffer(OH_AVCodec *codec, uint32_t index, OH_AVBuffer *buffer, void *userData) {
  (void)userData;
  EncodedFrame frame;
  {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    if (gDecoder.codec != codec || buffer == nullptr) {
      return;
    }
    if (gDecoder.queue.empty()) {
      gDecoder.waitingInputBuffer = buffer;
      gDecoder.waitingInputIndex = index;
      return;
    }
    frame = std::move(gDecoder.queue.front());
    gDecoder.queue.pop_front();
  }

  int32_t capacity = OH_AVBuffer_GetCapacity(buffer);
  uint8_t *address = OH_AVBuffer_GetAddr(buffer);
  if (capacity <= 0 || address == nullptr || frame.bytes.size() > static_cast<size_t>(capacity)) {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    gDecoder.lastError = -1001;
    return;
  }

  std::memcpy(address, frame.bytes.data(), frame.bytes.size());
  OH_AVCodecBufferAttr attr{};
  attr.pts = frame.ptsUs;
  attr.size = static_cast<int32_t>(frame.bytes.size());
  attr.offset = 0;
  attr.flags = frame.flags;
  if (OH_AVBuffer_SetBufferAttr(buffer, &attr) != AV_ERR_OK ||
      OH_VideoDecoder_PushInputBuffer(codec, index) != AV_ERR_OK) {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    gDecoder.lastError = -1002;
    return;
  }
  std::lock_guard<std::mutex> lock(gDecoder.mutex);
  ++gDecoder.submittedFrames;
}

void OnNewOutputBuffer(OH_AVCodec *codec, uint32_t index, OH_AVBuffer *buffer, void *userData) {
  (void)userData;
  if (buffer == nullptr) {
    OH_VideoDecoder_FreeOutputBuffer(codec, index);
    return;
  }
  OH_AVCodecBufferAttr attr{};
  OH_AVBuffer_GetBufferAttr(buffer, &attr);
  OH_AVErrCode error = AV_ERR_OK;
  if ((attr.flags & AVCODEC_BUFFER_FLAGS_EOS) != 0) {
    error = OH_VideoDecoder_FreeOutputBuffer(codec, index);
  } else {
    error = OH_VideoDecoder_RenderOutputBuffer(codec, index);
  }
  std::lock_guard<std::mutex> lock(gDecoder.mutex);
  if (error == AV_ERR_OK && (attr.flags & AVCODEC_BUFFER_FLAGS_EOS) == 0) {
    ++gDecoder.decodedFrames;
  } else if (error != AV_ERR_OK) {
    gDecoder.lastError = static_cast<int32_t>(error);
  }
}

void OnError(OH_AVCodec *codec, int32_t errorCode, void *userData) {
  (void)codec;
  (void)userData;
  std::lock_guard<std::mutex> lock(gDecoder.mutex);
  gDecoder.lastError = errorCode;
}

void OnStreamChanged(OH_AVCodec *codec, OH_AVFormat *format, void *userData) {
  (void)codec;
  (void)format;
  (void)userData;
}

void StopLocked() {
  gDecoder.codec = nullptr;
  gDecoder.window = nullptr;
  gDecoder.waitingInputBuffer = nullptr;
  gDecoder.waitingInputIndex = UINT32_MAX;
  gDecoder.queue.clear();
  gDecoder.started = false;
  gDecoder.codecName.clear();
}

void DestroyDetached(OH_AVCodec *codec, OHNativeWindow *window) {
  if (codec != nullptr) {
    OH_VideoDecoder_Stop(codec);
    OH_VideoDecoder_Destroy(codec);
  }
  if (window != nullptr) {
    OH_NativeWindow_DestroyNativeWindow(window);
  }
}

bool ReadArrayBuffer(napi_env env, napi_value value, std::vector<uint8_t> &out) {
  bool isArrayBuffer = false;
  if (napi_is_arraybuffer(env, value, &isArrayBuffer) != napi_ok || !isArrayBuffer) {
    return false;
  }
  void *data = nullptr;
  size_t length = 0;
  if (napi_get_arraybuffer_info(env, value, &data, &length) != napi_ok ||
      data == nullptr || length == 0 || length > MAX_FRAME_BYTES) {
    return false;
  }
  const auto *bytes = static_cast<const uint8_t *>(data);
  out.assign(bytes, bytes + length);
  return true;
}

napi_value Start(napi_env env, napi_callback_info info) {
  size_t argc = 6;
  napi_value args[6] = {nullptr, nullptr, nullptr, nullptr, nullptr, nullptr};
  napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);

  napi_value result = nullptr;
  napi_create_object(env, &result);
  SetNamed(env, result, "started", MakeBoolean(env, false));
  SetNamed(env, result, "hardware", MakeBoolean(env, false));
  SetNamed(env, result, "name", MakeString(env, ""));

  if (argc < 5) {
    SetNamed(env, result, "error", MakeString(env, "invalid_arguments"));
    return result;
  }

  size_t surfaceLength = 0;
  size_t mimeLength = 0;
  napi_get_value_string_utf8(env, args[0], nullptr, 0, &surfaceLength);
  napi_get_value_string_utf8(env, args[1], nullptr, 0, &mimeLength);
  std::string surfaceText(surfaceLength, '\0');
  std::string mimeText(mimeLength, '\0');
  napi_get_value_string_utf8(env, args[0], surfaceText.data(), surfaceLength + 1, &surfaceLength);
  napi_get_value_string_utf8(env, args[1], mimeText.data(), mimeLength + 1, &mimeLength);
  surfaceText.resize(surfaceLength);
  mimeText.resize(mimeLength);

  int32_t width = 0;
  int32_t height = 0;
  int32_t fps = 30;
  napi_get_value_int32(env, args[2], &width);
  napi_get_value_int32(env, args[3], &height);
  if (argc > 4) {
    napi_get_value_int32(env, args[4], &fps);
  }
  if (width <= 0 || height <= 0 || width > 8192 || height > 8192 || fps <= 0 || fps > 240) {
    SetNamed(env, result, "error", MakeString(env, "invalid_dimensions"));
    return result;
  }

  std::vector<uint8_t> codecConfig;
  if (argc > 5) {
    napi_valuetype configType = napi_undefined;
    napi_typeof(env, args[5], &configType);
    if (configType != napi_undefined && !ReadArrayBuffer(env, args[5], codecConfig)) {
      SetNamed(env, result, "error", MakeString(env, "invalid_codec_config"));
      return result;
    }
  }

  const char *mime = MimeForCodec(mimeText);
  OH_AVCapability *capability =
      mime == nullptr ? nullptr : OH_AVCodec_GetCapabilityByCategory(mime, false, HARDWARE);
  const char *codecName = capability == nullptr ? nullptr : OH_AVCapability_GetName(capability);
  if (codecName == nullptr || !OH_AVCapability_IsHardware(capability)) {
    SetNamed(env, result, "error", MakeString(env, "hardware_decoder_unavailable"));
    return result;
  }

  char *parseEnd = nullptr;
  uint64_t surfaceId = std::strtoull(surfaceText.c_str(), &parseEnd, 10);
  if (surfaceText.empty() || parseEnd == nullptr || *parseEnd != '\0' || surfaceId == 0) {
    SetNamed(env, result, "error", MakeString(env, "invalid_surface"));
    return result;
  }

  OH_AVCodec *previousCodec = nullptr;
  OHNativeWindow *previousWindow = nullptr;
  {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    previousCodec = gDecoder.codec;
    previousWindow = gDecoder.window;
    StopLocked();
  }
  DestroyDetached(previousCodec, previousWindow);

  OHNativeWindow *window = nullptr;
  if (OH_NativeWindow_CreateNativeWindowFromSurfaceId(surfaceId, &window) != 0 || window == nullptr) {
    SetNamed(env, result, "error", MakeString(env, "surface_unavailable"));
    return result;
  }

  OH_AVCodec *codec = OH_VideoDecoder_CreateByName(codecName);
  if (codec == nullptr) {
    OH_NativeWindow_DestroyNativeWindow(window);
    SetNamed(env, result, "error", MakeString(env, "create_decoder_failed"));
    return result;
  }

  OH_AVCodecCallback callback{OnError, OnStreamChanged, OnNeedInputBuffer, OnNewOutputBuffer};
  OH_AVFormat *format = OH_AVFormat_Create();
  OH_AVErrCode status = OH_VideoDecoder_RegisterCallback(codec, callback, nullptr);
  if (status == AV_ERR_OK) {
    status = OH_VideoDecoder_SetSurface(codec, window);
  }
  if (status == AV_ERR_OK && format != nullptr) {
    OH_AVFormat_SetIntValue(format, OH_MD_KEY_WIDTH, width);
    OH_AVFormat_SetIntValue(format, OH_MD_KEY_HEIGHT, height);
    OH_AVFormat_SetIntValue(format, OH_MD_KEY_FRAME_RATE, fps);
    OH_AVFormat_SetIntValue(format, OH_MD_KEY_PIXEL_FORMAT, AV_PIXEL_FORMAT_SURFACE_FORMAT);
    if (OH_AVCapability_IsFeatureSupported(capability, VIDEO_LOW_LATENCY)) {
      OH_AVFormat_SetIntValue(format, OH_MD_KEY_VIDEO_ENABLE_LOW_LATENCY, 1);
    }
    if (!codecConfig.empty()) {
      OH_AVFormat_SetBuffer(format, OH_MD_KEY_CODEC_CONFIG, codecConfig.data(), codecConfig.size());
    }
    status = OH_VideoDecoder_Configure(codec, format);
  } else if (format == nullptr) {
    status = AV_ERR_NO_MEMORY;
  }
  if (format != nullptr) {
    OH_AVFormat_Destroy(format);
  }
  if (status == AV_ERR_OK) {
    status = OH_VideoDecoder_Prepare(codec);
  }

  if (status != AV_ERR_OK) {
    OH_VideoDecoder_Destroy(codec);
    OH_NativeWindow_DestroyNativeWindow(window);
    SetNamed(env, result, "error", MakeString(env, "decoder_start_failed"));
    SetNamed(env, result, "name", MakeString(env, codecName));
    SetNamed(env, result, "hardware", MakeBoolean(env, true));
    return result;
  }

  {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    gDecoder.codec = codec;
    gDecoder.window = window;
    gDecoder.started = true;
    gDecoder.lastError = 0;
    gDecoder.submittedFrames = 0;
    gDecoder.decodedFrames = 0;
    gDecoder.codecName = codecName;
  }
  status = OH_VideoDecoder_Start(codec);
  if (status != AV_ERR_OK) {
    {
      std::lock_guard<std::mutex> lock(gDecoder.mutex);
      gDecoder.codec = nullptr;
      gDecoder.window = nullptr;
      gDecoder.started = false;
      gDecoder.codecName.clear();
    }
    OH_VideoDecoder_Destroy(codec);
    OH_NativeWindow_DestroyNativeWindow(window);
    SetNamed(env, result, "error", MakeString(env, "decoder_start_failed"));
    SetNamed(env, result, "name", MakeString(env, codecName));
    SetNamed(env, result, "hardware", MakeBoolean(env, true));
    return result;
  }

  SetNamed(env, result, "started", MakeBoolean(env, true));
  SetNamed(env, result, "hardware", MakeBoolean(env, true));
  SetNamed(env, result, "name", MakeString(env, codecName));
  SetNamed(env, result, "error", MakeString(env, ""));
  return result;
}

napi_value PushFrame(napi_env env, napi_callback_info info) {
  size_t argc = 3;
  napi_value args[3] = {nullptr, nullptr, nullptr};
  napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
  if (argc < 3) {
    return MakeBoolean(env, false);
  }

  std::vector<uint8_t> bytes;
  int64_t ptsUs = 0;
  bool keyFrame = false;
  if (!ReadArrayBuffer(env, args[0], bytes) ||
      napi_get_value_int64(env, args[1], &ptsUs) != napi_ok ||
      napi_get_value_bool(env, args[2], &keyFrame) != napi_ok) {
    return MakeBoolean(env, false);
  }

  EncodedFrame frame;
  frame.bytes = std::move(bytes);
  frame.ptsUs = ptsUs;
  frame.flags = keyFrame ? AVCODEC_BUFFER_FLAGS_SYNC_FRAME : AVCODEC_BUFFER_FLAGS_NONE;

  OH_AVCodec *codec = nullptr;
  OH_AVBuffer *buffer = nullptr;
  uint32_t index = UINT32_MAX;
  EncodedFrame ready;
  bool hasReady = false;
  {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    if (!gDecoder.started || gDecoder.codec == nullptr) {
      return MakeBoolean(env, false);
    }
    if (gDecoder.queue.size() >= MAX_QUEUED_FRAMES) {
      gDecoder.queue.pop_front();
    }
    gDecoder.queue.push_back(std::move(frame));
    if (gDecoder.waitingInputBuffer != nullptr) {
      codec = gDecoder.codec;
      buffer = gDecoder.waitingInputBuffer;
      index = gDecoder.waitingInputIndex;
      gDecoder.waitingInputBuffer = nullptr;
      gDecoder.waitingInputIndex = UINT32_MAX;
      ready = std::move(gDecoder.queue.front());
      gDecoder.queue.pop_front();
      hasReady = true;
    }
  }
  if (hasReady) {
    int32_t capacity = OH_AVBuffer_GetCapacity(buffer);
    uint8_t *address = OH_AVBuffer_GetAddr(buffer);
    if (capacity > 0 && address != nullptr && ready.bytes.size() <= static_cast<size_t>(capacity)) {
      std::memcpy(address, ready.bytes.data(), ready.bytes.size());
      OH_AVCodecBufferAttr attr{};
      attr.pts = ready.ptsUs;
      attr.size = static_cast<int32_t>(ready.bytes.size());
      attr.offset = 0;
      attr.flags = ready.flags;
      if (OH_AVBuffer_SetBufferAttr(buffer, &attr) == AV_ERR_OK &&
          OH_VideoDecoder_PushInputBuffer(codec, index) == AV_ERR_OK) {
        std::lock_guard<std::mutex> lock(gDecoder.mutex);
        ++gDecoder.submittedFrames;
      }
    }
  }
  return MakeBoolean(env, true);
}

napi_value Stats(napi_env env, napi_callback_info info) {
  (void)info;
  napi_value result = nullptr;
  napi_create_object(env, &result);
  std::lock_guard<std::mutex> lock(gDecoder.mutex);
  SetNamed(env, result, "queued", MakeUint32(env, static_cast<uint32_t>(gDecoder.queue.size())));
  SetNamed(env, result, "submitted", MakeUint32(env, static_cast<uint32_t>(gDecoder.submittedFrames)));
  SetNamed(env, result, "decoded", MakeUint32(env, static_cast<uint32_t>(gDecoder.decodedFrames)));
  SetNamed(env, result, "lastError", MakeUint32(env, static_cast<uint32_t>(gDecoder.lastError)));
  return result;
}

napi_value Stop(napi_env env, napi_callback_info info) {
  (void)info;
  OH_AVCodec *codec = nullptr;
  OHNativeWindow *window = nullptr;
  {
    std::lock_guard<std::mutex> lock(gDecoder.mutex);
    codec = gDecoder.codec;
    window = gDecoder.window;
    StopLocked();
  }
  DestroyDetached(codec, window);
  return nullptr;
}

napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor properties[] = {
      {"probeHardwareDecoder", nullptr, Probe, nullptr, nullptr, nullptr, napi_default, nullptr},
      {"startHardwareDecoder", nullptr, Start, nullptr, nullptr, nullptr, napi_default, nullptr},
      {"pushDecodeFrame", nullptr, PushFrame, nullptr, nullptr, nullptr, napi_default, nullptr},
      {"decoderStats", nullptr, Stats, nullptr, nullptr, nullptr, napi_default, nullptr},
      {"stopHardwareDecoder", nullptr, Stop, nullptr, nullptr, nullptr, napi_default, nullptr},
  };
  napi_define_properties(env, exports, sizeof(properties) / sizeof(properties[0]), properties);
  return exports;
}

}  // namespace

static napi_module gCodecModule = {
    .nm_version = 1,
    .nm_flags = 0,
    .nm_filename = nullptr,
    .nm_register_func = Init,
    .nm_modname = "uucodec",
    .nm_priv = nullptr,
    .reserved = {0},
};

extern "C" __attribute__((constructor)) void RegisterUuCodecModule(void) {
  napi_module_register(&gCodecModule);
}
