param(
  [string]$BuildRoot = 'C:\Codex\Builds\UU-HarmonyOS-Next'
)

$ErrorActionPreference = 'Stop'
$sourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$deveco = 'C:\Program Files\Huawei\DevEco Studio'

New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
robocopy $sourceRoot $BuildRoot /E /NFL /NDL /NJH /NJS /NP /XD node_modules .hvigor build .cxx oh_modules dist | Out-Null
if ($LASTEXITCODE -gt 7) { throw "robocopy failed: $LASTEXITCODE" }

$env:NODE_HOME = Join-Path $deveco 'tools\node'
$env:JAVA_HOME = Join-Path $deveco 'jbr'
$env:DEVECO_SDK_HOME = Join-Path $deveco 'sdk'
$env:PATH = "$env:NODE_HOME;$env:JAVA_HOME\bin;$env:PATH"

Push-Location $BuildRoot
try {
  & "$env:NODE_HOME\npm.cmd" --prefix web ci --ignore-scripts
  if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
  & "$env:NODE_HOME\npm.cmd" --prefix web test
  if ($LASTEXITCODE -ne 0) { throw 'Web tests failed' }
  & "$env:NODE_HOME\npm.cmd" --prefix web run build
  if ($LASTEXITCODE -ne 0) { throw 'Web build failed' }

  $rawfile = Join-Path $BuildRoot 'entry\src\main\resources\rawfile'
  New-Item -ItemType Directory -Force -Path $rawfile | Out-Null
  Copy-Item -Path (Join-Path $BuildRoot 'web\dist\*') -Destination $rawfile -Recurse -Force

  & (Join-Path $deveco 'tools\ohpm\bin\ohpm.bat') install
  if ($LASTEXITCODE -ne 0) { throw 'ohpm install failed' }

  & (Join-Path $deveco 'tools\hvigor\bin\hvigorw.bat') `
    --mode module -p product=default -p module=entry@default `
    -p buildMode=release assembleHap --no-daemon
  if ($LASTEXITCODE -ne 0) { throw 'HAP build failed' }
}
finally {
  Pop-Location
}

$hap = Join-Path $BuildRoot 'entry\build\default\outputs\default\entry-default-unsigned.hap'
Get-FileHash -Algorithm SHA256 -LiteralPath $hap
Write-Output $hap
