# UU 远程 Next

HarmonyOS 7.0 / API 26 的**手机和平板控制端**实验工程。

本项目基于 MIT 许可的上游项目继续移植，保留已实现的 UU 协议、安全存储、网络边界和登录流程，并新增 HarmonyOS 原生 AVCodec 硬件视频解码入口。它不是网易官方产品。

## 产品范围

- 只做控制端：用 HarmonyOS 手机或平板控制本人账号下已登录的 Windows / Mac 官方 UU 客户端。
- 不做鸿蒙被控端，不采集本机屏幕，不注入本机输入，也不注册本机供其他设备反向控制。
- 使用 Stage 模型、ArkTS、ArkUI、ArkWeb 和 HarmonyOS NDK。
- `deviceTypes` 为 `phone`、`tablet`；compile/target SDK 为 API 26。

## 当前实现

- 本人账号短信登录、登录态安全恢复和设备列表。
- 与官方 Windows / Mac UU 的信令、WebRTC H.264 接收、鼠标与基础键盘。
- 首次签名时自动导入公开的 UU 客户端协议常量到 HUKS；账号令牌单独保存在 AssetStoreKit。
- 固定 UU API/信令域名、系统 TLS 校验、重定向拒绝和受限原生桥。
- ArkUI `XComponent(SURFACE)` 与 `libuucodec.so`。
- 通过 `OH_AVCodec_GetCapabilityByCategory(..., HARDWARE)` 强制查询硬件 codec。
- 通过 `OH_VideoDecoder_CreateByName`、`OH_VideoDecoder_SetSurface`、`Configure`、`Prepare`、`Start` 建立硬解。
- WebRTC encoded stream → NAPI → 原生 AVCodec；ArkWeb 自带解码保留为回退。
- 原生 Surface 上的基础触控和基础硬件键盘输入。
- `auto_rotation` 横竖屏切换；手机和平板共用同一 Stage Ability。
- 直接触控模式使用 APK 中的 `SLOTMULTIPRESS/SLOTMULTIRELEASE` 协议，最多同时转发 6 个触点。
- 触控板模式支持单指相对移动、单指点击、双指滚动和双指点击右键。
- 连接参数支持自定义 Kbps 码率、30/60/90/120/144 帧；120 帧通过 `fpsCount` 字段发送。
- “超级屏”开关请求高分辨率虚拟显示，作为实验能力保留，仍需真机逐项核对被控端行为。

## 原生视频数据路径

```text
官方 Windows / Mac UU
  → HTTPS signaling
  → WebRTC H.264
  → ArkWeb encoded video stream
  → UUBridge.pushVideoFrame
  → NAPI libuucodec.so
  → OH_VideoDecoder
  → XComponent Surface
```

原生模块使用本机 API 26 SDK 中的：

- `native_avcodec_videodecoder.h`
- `native_avcapability.h`
- `native_avbuffer.h`
- `external_window.h`

详细设计见 [docs/HarmonyOS7-Native-Decoder.md](docs/HarmonyOS7-Native-Decoder.md)。上游原说明归档在 [docs/UPSTREAM-README.md](docs/UPSTREAM-README.md)。

## 已完成的构建验证

- DevEco Studio 26.0.0.851。
- HarmonyOS SDK 26.0.0.105 / API 26。
- Web TypeScript 编译：PASS。
- Web 单元测试：138/138 PASS。
- CMake/Ninja 原生编译：PASS。
- ArkTS 编译：PASS。
- HAP 打包：PASS。
- HAP 内已确认存在 `libs/arm64-v8a/libuucodec.so`。

真机仍待验证：ArkWeb encoded streams、实际硬件 codec 名称、首帧、持续播放、触控、键盘、后台切换与网络切换。

## 构建

DevEco 的 hvigor 不接受含中文字符的项目路径。Windows 下建议同步到：

```text
C:\Codex\Builds\UU-HarmonyOS-Next
```

项目内提供了 `build-windows.ps1`。也可以执行：

```powershell
$env:NODE_HOME = 'C:\Program Files\Huawei\DevEco Studio\tools\node'
$env:JAVA_HOME = 'C:\Program Files\Huawei\DevEco Studio\jbr'
$env:DEVECO_SDK_HOME = 'C:\Program Files\Huawei\DevEco Studio\sdk'
$env:PATH = "$env:NODE_HOME;$env:JAVA_HOME\bin;$env:PATH"

& "$env:NODE_HOME\npm.cmd" --prefix web ci --ignore-scripts
& "$env:NODE_HOME\npm.cmd" --prefix web run build
Copy-Item -Path .\web\dist\* -Destination .\entry\src\main\resources\rawfile -Recurse -Force
& 'C:\Program Files\Huawei\DevEco Studio\tools\ohpm\bin\ohpm.bat' install
& 'C:\Program Files\Huawei\DevEco Studio\tools\hvigor\bin\hvigorw.bat' `
  --mode module -p product=default -p module=entry@default `
  -p buildMode=release assembleHap --no-daemon
```

## 真机调试

已在 `PLA-AL10`、HarmonyOS `7.0.0.111(SP12C00E111R7P3)`、API 26 上确认 HDC 可用。安装前仍需在 DevEco Studio 中完成调试签名。

1. Project Structure → 签名配置。
2. 选择 `default`，勾选“自动生成签名文件”。
3. 登录华为开发者账号并生成 Profile。
4. 构建并安装到设备。
5. 直接使用本人手机号完成短信登录，无需手工导入协议材料。
6. 先确认 ArkWeb 回退画面，再打开控制中心选择“启用 HarmonyOS 硬件解码”。

关键 HiLog：

- `UU_REA_CODEC|READY|<codecName>`：原生硬件解码器已创建。
- `UU_REA_RTC|ENCODED_STREAMS_READY`：ArkWeb 可提供编码视频帧。
- `UU_REA_RTC|ENCODED_STREAMS_UNAVAILABLE`：只能继续使用浏览器解码。

只有真实 Windows / Mac 桌面首帧和持续帧增长才算硬解链路通过。

## 安全边界

- 不关闭 TLS 校验，不绕过固定域名和重定向限制。
- 不读取或上传令牌、验证码、签名材料、SDP/candidate 原文。
- 协议签名的应用级常量只用于 UU 客户端签名兼容，不包含账号、短信验证码或登录令牌。
- 不把任意外部页面加载进带原生桥的 WebView。
- 不伪造官方签名或发布身份。

## 许可

本项目自身修改采用 MIT 许可；上游来源与第三方许可见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
