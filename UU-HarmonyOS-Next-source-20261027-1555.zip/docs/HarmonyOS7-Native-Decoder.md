# HarmonyOS 7 原生视频硬解设计

## 数据路径

```text
官方 Windows / Mac UU
  → HTTPS signaling
  → WebRTC H.264
  → ArkWeb encoded video stream
  → UUBridge.pushVideoFrame
  → NAPI libuucodec.so
  → OH_VideoDecoder
  → ArkUI XComponent Surface
```

网页视频元素继续作为回退。只有用户显式点击“启用 HarmonyOS 硬件解码”后，Web 页面才把 encoded frame 转发给原生层；原生桥在 `nativeVideoEnabled` 为真之前拒绝所有帧。

## 硬件选择

原生模块不依赖 MIME 推荐结果直接创建实例，而是：

1. 使用 `OH_AVCodec_GetCapabilityByCategory(mime, false, HARDWARE)`。
2. 使用 `OH_AVCapability_IsHardware` 再次确认硬件类别。
3. 使用 `OH_AVCapability_GetName` 取得明确解码器名称。
4. 使用 `OH_VideoDecoder_CreateByName` 创建该硬件实例。

这样可以避免在存在同名软件解码器时误选软解。

## Surface 与低延迟

- ArkUI 始终创建 `XComponentType.SURFACE`，通过 `XComponentController.onSurfaceCreated` 把 surface ID 交给桥。
- NativeWindow 通过 `OH_NativeWindow_CreateNativeWindowFromSurfaceId` 建立。
- 解码器使用 `OH_VideoDecoder_SetSurface` 输出到该 Surface。
- 像素格式为 `AV_PIXEL_FORMAT_SURFACE_FORMAT`。
- 当 `OH_AVCapability_IsFeatureSupported(..., VIDEO_LOW_LATENCY)` 为真时设置低延迟参数。

## 帧格式

WebRTC encoded frame 先尝试从 AVCC 长度前缀格式转换为 Annex-B：

- 四字节长度前缀 NAL 转为 `00 00 00 01` 起始码。
- 已是 Annex-B 的帧保持不变。
- SDP 中的 `sprop-parameter-sets` 转换为带起始码的 SPS/PPS，并通过 `OH_MD_KEY_CODEC_CONFIG` 传入解码器。

## 资源释放

- 页面退出、连接清理、桥 dispose 或用户返回软件界面时调用 `stopHardwareDecoder`。
- 解码器、NativeWindow、输入回调所持有的 buffer 均释放。
- 原生 Surface 销毁时清空 surface ID，防止后续帧使用失效 Surface。

## 真机需要确认

- 设备实际选择的是硬件 codec，而不是回退路径。
- `libuucodec.so` 与 ArkTS 编译产物一起进入 HAP。
- 首帧后持续帧数增长，不能只以 decoder READY 作为成功。
- 手机与平板的分辨率变化不能导致 stale Surface 或 buffer 泄漏。
