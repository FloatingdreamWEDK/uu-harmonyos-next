# UU 远程 Next

HarmonyOS 7.0 / API 26 的手机和平板控制端实验工程。

本项目基于 MIT 许可的 [UU-HarmonyOS](https://github.com/lukedd666-sudo/UU-HarmonyOS) 主控实现继续移植，保留其协议、安全存储和网络边界，并增加 HarmonyOS 原生 AVCodec 硬件视频解码入口。它不是网易官方产品。

## 当前范围

- 只做控制端：手机或平板控制本人账号下已登录的 Windows / Mac 官方 UU 客户端。
- 不做鸿蒙被控端，不采集本机屏幕，不注入本机输入，不注册鸿蒙设备供官方客户端反向控制。
- Stage 模型、ArkTS、ArkUI、ArkWeb 与 NDK AVCodec。
- target/compile SDK 为 HarmonyOS 7.0 / API 26，`deviceTypes` 为 `phone`、`tablet`。

## 已实现

- 本人账号短信登录、登录态安全恢复和设备列表。
- 与官方 Windows / Mac UU 的信令、WebRTC H.264 接收、鼠标与基础键盘。
- HUKS 协议签名材料和 AssetStoreKit 登录态。
- 固定 UU API/信令域名、系统 TLS 校验、重定向拒绝和受限原生桥。
- `XComponent` Surface 与 `libuucodec.so` 原生解码模块。
- 通过 `OH_AVCodec_GetCapabilityByCategory(..., HARDWARE)` 查找硬件 H.264/H.265 解码器。
- 通过 `OH_VideoDecoder_CreateByName`、`OH_VideoDecoder_SetSurface`、`OH_VideoDecoder_Configure`、`Prepare`、`Start` 建立硬件解码。
- 通过 WebRTC encoded streams 将 H.264 访问单元送入原生 AVCodec；浏览器解码作为回退。
- 原生 Surface 上的基础触控与基础硬件键盘输入。

## 尚未真机验收

工程已在本机 DevEco Studio 26.0.0.851 / API 26 完整编译生成 unsigned HAP，并通过 138 项 Web 测试。以下项目必须由手机和平板真机确认：

- ArkWeb 对 `createEncodedStreams` / `encodedInsertableStreams` 的运行时支持。
- 指定设备是否公开提供 H.264 硬件解码能力，以及实际 codec 名称。
- 原生 Surface 首帧、持续播放、触控和硬件键盘。
- 手机和平板布局、软键盘、后台切换和网络切换。
- Windows / Mac 两端不同官方版本的协议兼容性。

“编译通过”不等同于“真机远控通过”。测试记录必须分别区分登录、设备列表、信令、首帧、持续画面、鼠标、键盘和断开清理。

## 构建

DevEco 的 hvigor 不接受含中文字符的项目路径。Windows 下建议将源码同步到：

```text
C:\Codex\Builds\UU-HarmonyOS-Next
```

也可以直接运行本目录的 `build-windows.ps1`。核心命令：

```powershell
$env:NODE_HOME = 'C:\Program Files\Huawei\DevEco Studio\tools\node'
$env:JAVA_HOME = 'C:\Program Files\Huawei\DevEco Studio\jbr'
$env:DEVECO_SDK_HOME = 'C:\Program Files\Huawei\DevEco Studio\sdk'
$env:PATH = "$env:NODE_HOME;$env:JAVA_HOME\bin;$env:PATH"

& "$env:NODE_HOME\npm.cmd" --prefix web ci --ignore-scripts
& "$env:NODE_HOME\npm.cmd" --prefix web run build
Copy-Item -Path .\web\dist\* -Destination .\entry\src\main\resources\rawfile -Recurse -Force
& 'C:\Program Files\Huawei\DevEco Studio\tools\ohpm\bin\ohpm.bat' install
& 'C:\Program Files\Huawei\DevEco Studio\tools\hvigor\bin\hvigorw.bat' `
  --mode module -p product=default -p module=entry@default `
  -p buildMode=release assembleHap --no-daemon
```

产物：

```text
entry/build/default/outputs/default/entry-default-unsigned.hap
```

## 真机调试

1. 用 DevEco Studio 打开工程并连接 HarmonyOS 7.0 手机或平板。
2. 在 DevEco Studio 的 Project Structure → Signing Configs 中启用自动签名。
3. 安装运行，完成短信登录。
4. 在“设置 → 开发者设置 → 协议材料”中导入合法取得的协议签名材料。材料不会写入源码或仓库。
5. 确认设备列表中出现本人 Windows / Mac，先使用 ArkWeb 回退路径连接并确认画面。
6. 打开控制中心，启用“HarmonyOS 硬件解码”。
7. 记录 `UU_REA_CODEC|READY|<codec名>` 和真实画面结果；只看到 `READY` 不算硬件解码通过。

若设备不支持 encoded streams，日志会出现 `UU_REA_RTC|ENCODED_STREAMS_UNAVAILABLE`，应保留 ArkWeb 回退并提交 HiLog，不能把回退画面记为原生硬解成功。

## 安全边界

- 不关闭 TLS 校验，不添加任意域名绕过。
- 不读取或上传用户令牌、验证码、签名材料、SDP/candidate 原文。
- 不复制任意外部网页到带原生桥的 WebView。
- 不伪造官方签名或发布身份。

## 来源与许可

- 本项目自身修改继续采用 MIT 许可。
- 上游实现及固定来源见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
- 原始上游说明保留在 [README.md](README.md)。
- HarmonyOS AVCodec 头文件与运行库来自本机 HarmonyOS SDK，遵循其 SDK 许可。
